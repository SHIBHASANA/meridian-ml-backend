// Set the public address of the Meridian ML backend (no trailing slash), e.g. "https://meridian-api.onrender.com".
// Leave empty to run without the ML service. Visitors can also paste an address in the AI analysis view.
// Never put secret keys in this file: it is public.
window.MERIDIAN_API_URL = "";
