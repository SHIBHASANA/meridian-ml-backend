# Meridian: hybrid rule-based + machine-learning crew health monitor

Research and decision-support demonstration. Not a medical device. All vitals are simulated, and the model is trained on SYNTHETIC data.

## Structure
```
meridian/
  frontend/  index.html, assets/config.js, _headers, netlify.toml   (static site, deploy to Netlify)
  backend/   app.py, model.py, train_model.py, test_api.py, requirements.txt, Procfile, models/
  README.md
```

## What is ML and what is not
- **Rules (existing):** thresholds, personal-baseline z-scores, multi-indicator patterns. Programmed, transparent.
- **ML (new, AI analysis view):** scikit-learn Isolation Forest (StandardScaler + 300 trees) analysing 8 features together: heart rate, SpO2, temperature, systolic pressure, respiration, recent sleep, recent stress, hydration.
- Diastolic pressure is not used because the dashboard does not simulate it.
- CO2 and radiation are NOT model inputs. They are shown separately as environmental hazards.
- The illustrative health score on the overview is unrelated to the ML score.

## Dataset (read this)
No real or public dataset was used. The training environment had no internet access, so the model is trained on synthetic data generated in `model.py` from illustrative "healthy adult" means and standard deviations. It is not real astronaut data and not clinical data, and no citation is claimed. Future work: replace with a documented public biomedical dataset and validate with flight surgeons.

## Run locally
```
cd backend
pip install -r requirements.txt
python train_model.py      # trains, evaluates, writes models/meridian_iforest.joblib and metrics.json
python test_api.py         # API tests (Flask test client)
python app.py              # http://localhost:5000
```
Open `frontend/index.html` through any static server, go to **AI analysis**, paste `http://localhost:5000`, click Connect.

## API
- `GET /api/health` returns model status, version and training date.
- `POST /api/analyze` with `{"crew":"name","features":{hr,spo2,temp,sys,rr,sleep,stress,hyd}}` returns classification (`normal_pattern`, `unusual_pattern`, `significant_anomaly`), score, percentile versus held-out synthetic normals, top contributing features, and a disclaimer.
- Missing, non-numeric, NaN, boolean or implausible values return 422. Non-JSON returns 400.
- Contributors: how much the score improves if one feature is replaced by its training median, plus its z-score. This explains the model's score. It is not a medical cause.

## Actual evaluation (synthetic data, seed 42, from models/metrics.json)
Train: 6000 synthetic normals. Test: 2000 held-out normals plus 2000 synthetic anomalies (500 each of cardiac-like, fever/dehydration-like, hypoxia-like, sleep/stress-like).

| Threshold | Precision | Recall | F1 | False-positive rate | Confusion (TN/FP/FN/TP) | ROC AUC |
|---|---|---|---|---|---|---|
| "Unusual" (1st percentile of validation normals) | 0.989 | 0.842 | 0.910 | 0.009 | 1982/18/316/1684 | 0.991 |
| "Significant" (0.1th percentile) | 0.998 | 0.595 | 0.745 | 0.001 | 1998/2/811/1189 | 0.991 |

Recall at the "unusual" threshold by pattern: cardiac-like 0.998, fever/dehydration-like 0.980, hypoxia-like 0.984, **sleep/stress-like 0.406**, **subtle drift 0.464** (subtle drift excluded from headline numbers).

These anomalies were written by the developer, so the numbers are optimistic and say nothing about real crews. False negatives: shifts in only one or two indicators and personal-baseline drift are often missed. False positives: about 1% of normal synthetic readings are flagged, and real physiology varies more than the synthetic data.

## Deploy
**Frontend (Netlify):** upload the `frontend` folder to Netlify Drop (or replace the files of your existing site). Set `assets/config.js` to your backend URL, or paste it in the AI analysis view. The backend must be HTTPS, because the Netlify page is HTTPS.

**Backend (free option, e.g. Render web service):** root directory `backend`, build `pip install -r requirements.txt`, start `gunicorn app:app`. Set env `ALLOWED_ORIGINS` to your Netlify address. Check the host's current free-tier terms. Free web services commonly sleep when idle, so the first request can be slow, and the dashboard shows "unreachable" until it wakes. The model file (about 3.6 MB) is committed, so no training is needed at deploy time. No API keys are used or needed.

**Status:** the backend has NOT been deployed by me, so there is no public API URL yet. Until you deploy it and set the address, the AI analysis view shows "Not connected" and the rest of Meridian works as before.
